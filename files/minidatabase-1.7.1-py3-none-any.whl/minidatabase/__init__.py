if __name__ == "__main__":
    import minidatabase
    minidatabase.minidb.main()
